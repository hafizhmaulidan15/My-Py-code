file = open("file2.txt", 'rt')
print(file.read(10))
file.close()
