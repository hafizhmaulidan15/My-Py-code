# membuka file3.txt
f = open("file3.txt", "w")
# membuat sebuah looping dari angkat 987 sampai 1000
for i in range(987, 1001):
    # menuliskan looping pada file text
    f.writelines(f"tampilkan urutan line ke = {i} \n")

# close file
f.close()

# membuka file3 dengan metode r (read)
file = open("file3.txt", "r")
# menampilkan file
print(file.read())
# menutup file
file.close()
